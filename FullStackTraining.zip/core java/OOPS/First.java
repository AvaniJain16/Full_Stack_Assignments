
class Second{  
  First obj;  
  Second(First obj){  
    this.obj=obj; 
	System.out.println("constructor");	
  }  
  void display(){  
   System.out.println(obj.num); 
   
  }  
}  
class First{  
  int num=5;  
  First(){  
  Second s=new Second(this);  
  s.display();  
  }  
  public static void main(String args[]){  
  First f=new First();  
  }  
}  