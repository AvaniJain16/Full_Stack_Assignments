class DemoConstruct{
int number;
String s;
DemoConstruct(){
System.out.println("Constructor is being called");
}
DemoConstruct(int number, String s){
	this.number=number;
	this.s=s;
}
public static void main(String[] args){
DemoConstruct c1 = new DemoConstruct();
DemoConstruct c2 = new DemoConstruct(10,"abc");
System.out.println(c1.number);
System.out.println(c2.s);

}
}