class Test{  
void n(){
System.out.println("new");
}  
void o(){  
System.out.println("old");  
this.n();  
}  
}  
class InvokeMtdImplicit{  
public static void main(String args[]){  
Test t=new Test();  
t.o();  
}}  