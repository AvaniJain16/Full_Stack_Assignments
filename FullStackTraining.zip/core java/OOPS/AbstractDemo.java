abstract class Parent{
abstract void gender();
}
class Mother extends Parent{
void gender(){
System.out.println("Mother is female");
}
}
class Father extends Parent{
void gender(){
System.out.println("Father is male");
}
public static void main(String[] args){
Mother m= new Mother();
m.gender();
Father f= new Father();
f.gender();
}
}