class SingleLevel{
void inherit(){
System.out.println("Inheriting");}
}
class Child extends SingleLevel{
public static void main(String[] args){
Child c= new Child();
c.inherit();

}
}