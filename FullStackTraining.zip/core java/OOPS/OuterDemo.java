 class Outer{
static int i=100;
class Inner{
void show(){
System.out.println("inside inner");
System.out.println(Outer.i);
}
}
}
public class OuterDemo{
public static void main(String[] args){
//Outer o= new Outer();
//Outer.Inner oi= o.new Inner();
Outer.Inner oi= new Outer.Inner();
oi.show();
}

}