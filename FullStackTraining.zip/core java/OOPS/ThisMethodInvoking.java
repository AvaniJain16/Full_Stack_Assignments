class ThisMethodInvoking{
void display(){
System.out.println("this is display..");
}
void show(){
System.out.println("This is show");
display();
}
public static void main(String[] args){
ThisMethodInvoking m = new ThisMethodInvoking();
m.show();
}
}