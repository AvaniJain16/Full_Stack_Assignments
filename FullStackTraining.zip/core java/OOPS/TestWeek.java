enum Week {
  SUNDAY(1),MONDAY(8),TUESDAY(9),WEDNESDAY(8),THRUSDAY(9),FRIDAY(8),SATURDAY(1);
  int hours;
  Week(int hours){
	  this.hours=hours;
  }
}
public class TestWeek {
   public static void main(String args[]){
      Week w;
      w = Week.SUNDAY;
      switch(w) {
         case SUNDAY:
            System.out.println("Today is Sunday!");
			System.out.println("You need to work "+Week.valueOf("SUNDAY") +"hours.");
			System.out.println("Sunday is "+(Week.valueOf("SUNDAY").ordinal()+1) +"st day of week.");
            break;
         case MONDAY:
            System.out.println("Today is Monday!");
			System.out.println("You need to work "+Week.value("MONDAY") +"hours.");
			System.out.println("Monday is "+(Week.valueOf("MONDAY").ordinal()+1) +"nd day of week.");
            break;
         case TUESDAY:
            System.out.println("Today is Tuesday!");
			System.out.println("You need to work "+Week.value("TUESDAY") +"hours.");
			System.out.println("Tuesday is "+(Week.valueOf("TUESDAY").ordinal()+1) +"rd day of week.");
            break;
         case WEDNESDAY:
            System.out.println("Today is Wednesday!");
			System.out.println("You need to work "+Week.value("WEDNESDAY") +"hours.");
			System.out.println("Wednesday is "+(Week.valueOf("WEDNESDAY").ordinal()+1) +"th day of week.");
            break;
         case THRUSDAY:
            System.out.println("Today is Thrusday!");
			System.out.println("You need to work "+Week.value("THRUSDAY") +"hours.");
			System.out.println("Thrusday is "+(Week.valueOf("THRUSDAY").ordinal()+1) +"th day of week.");
            break;
		 case FRIDAY:
            System.out.println("Today is Friday!");
			System.out.println("You need to work "+Week.value("FRIDAY") +"hours.");
			System.out.println("Friday is "+(Week.valueOf("FRIDAY").ordinal()+1) +"st day of week.");
            break;
		 case SATURDAY:
            System.out.println("Today is Saturday!");
			System.out.println("You need to work "+Week.value("SATURDAY") +"hours.");
			System.out.println("Suaturay is "+(Week.valueOf("SATURDAY").ordinal()+1) +"th day of week.");
            break;
         default:
			System.out.println("This is not a week day!");
            break;
      }
   }
}
