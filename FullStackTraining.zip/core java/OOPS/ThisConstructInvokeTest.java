package Rough;
class ThisConstructInvoke{
String Name;
int Age;
ThisConstructInvoke(){
System.out.println("No argument constructor");
}
ThisConstructInvoke(String Name){
System.out.println("One rgument constructor");
}
ThisConstructInvoke(String Name, int Age){
	this();
System.out.println("Two argument constructor");
}

}
class ThisConstructInvokeTest{
public static void main(String[] args){
ThisConstructInvoke i= new ThisConstructInvoke("Yash",23);
}
}