class Box
{
    float width;
    float height;
    float depth;
    
    
    Box(float w, float h, float d)
    {
        width = w;
        height = h;
        depth = d;
    }
    
    float volume()
    {
        return width * height * depth;
    }
}

class BoxDemo
{
    public static void main(String args[])
    {
        Box mybox = new Box(100, 200, 150);
        float vol;
        System.out.println("Volume of the box is " + mybox.volume());
    }
}