class Parent{
Parent(){
	System.out.println("parent class constructor");
}
}
class Child extends Parent{
Child(){
	System.out.println("Child class constructor");
}
public static void main( String[] args)
{
	Child c = new Child();
	
}}