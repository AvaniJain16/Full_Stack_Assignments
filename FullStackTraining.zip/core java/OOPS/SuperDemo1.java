class Vehicle{
String color="black";
}
class Maruti extends Vehicle{
String color="white";
void printColor(){
System.out.println(color);
System.out.println(super.color);
}
}
class SuperDemo1{
public static void main(String args[]){
Maruti d=new Maruti();
d.printColor();
}}
