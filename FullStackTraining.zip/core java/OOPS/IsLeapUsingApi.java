import java.time.LocalDate;
import java.util.Scanner;

public class IsLeapUsingApi {
   public static void main(String args[]) {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter any year: ");
      int year = sc.nextInt();
      LocalDate givenDate = LocalDate.of(year, 01, 01);
      boolean bool = givenDate.isLeapYear();
      if(bool){
         System.out.println("Given year is a leap year ");
      }else{
         System.out.println("Given year is not a leap year ");
      }
   }
}