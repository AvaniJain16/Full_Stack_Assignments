import java.util.*; 
class Square{
public static void main(String[] args)  
{  
Scanner sc= new Scanner(System.in);   
System.out.print("Enter a Integer: ");  
String str= sc.nextLine();               
int i,s;
   try {
   i = Integer.parseInt(str);
   s=i*i;
   System.out.println("The square value: " +s);
}
catch (Exception e) {
   System.out.println("Entered Input is not a valid format for an integer");  
}  

}  
}