class Parent {
   String parentName;
   Parent(String name1){
      parentName = name1;
   }
   public void display() {
      System.out.println(parentName);
   }
}
class Child extends Parent {
   String childName;
   Child(String name2) {
      super(name2);
      childName = name2;
   }
   public void display() {
      System.out.println(childName);
   }
}
public class Main {
   public static void main(String args[]) {
      Child c1 = new Child("Yash");
      Parent p1 = new Parent("Manish");
      p1 = c1;
	  p1.display();

      Parent p2 = new Parent("Rajat");
      Child c2 = (Child)p2;
   }
}