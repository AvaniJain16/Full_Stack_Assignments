class Patient
{
    String patientName;
    double height;
    double weight;
    
    
    Patient(String pn, double h, double w)
    {
	    patientName = pn;
        weight = w;
        height = h;
    }
    
    double BMI()
    {
        return weight / (height * height);
    }
}

class PatientDemo
{
    public static void main(String args[])
    {
        Patient patient1 = new Patient("yash", 76, 1.6);
        double vol;
        System.out.println("The BMI of patient is: " + patient1.BMI());
    }
}