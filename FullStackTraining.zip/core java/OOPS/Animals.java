class Animal{
void eat(){
System.out.println("Eating");
}
void sleep(){
System.out.println("Sleeping");
}
}
class Bird{
void eat(){
System.out.println("Bird is eating");
}
void sleep(){
System.out.println("Bird is sleeping");
}
void fly(){
System.out.println("Bird is flying");
}
}
class Animals{
public static void main(String[] args){
Animal a= new Animal();
a.eat();
a.sleep();
Bird b= new Bird();
b.eat();
b.sleep();
b.fly();
}
}