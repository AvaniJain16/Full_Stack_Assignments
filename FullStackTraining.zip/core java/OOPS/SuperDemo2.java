class Vehicle{
void color(){
System.out.println("Vehicle is of black color");}
}
class Maruti extends Vehicle{
void color(){
System.out.println("Maruti is of white color");
}
void printColor(){
color();
super.color();
}
}
class SuperDemo2{
public static void main(String args[]){
Maruti d=new Maruti();
d.printColor();
}}