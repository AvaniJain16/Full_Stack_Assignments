class ThisReferClassInst{  
int num;  
String name;   
ThisReferClassInst(int num,String name){  
this.num=num;  
this.name=name;   
}  
void display(){
System.out.println(num+" "+name+" ");
}  
}  
  
class ThisIs{  
public static void main(String[] args){  
ThisReferClassInst s1=new ThisReferClassInst(68,"abc");  
ThisReferClassInst s2=new ThisReferClassInst(92,"xyz");  
s1.display();  
s2.display();  
}}  