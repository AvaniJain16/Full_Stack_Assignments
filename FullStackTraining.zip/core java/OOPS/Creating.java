class Person{
String Name;
int DateOfBirth;
void who1(){System.out.println("This is a person");
}}
class Teacher extends Person{
int Salary;
String Subject;
void who2(){System.out.println("This is a Teacher");
}}
class Student extends Person{
int Student_id;
void who3(){System.out.println("This is a Student");
}}
class CollegeStudent extends Student{
String CollegeName;
String Year;
void who4(){System.out.println("This is a College student");
}}
class Creating{
	public static void main(String[] args){
Person p=new Person();
p.who1();
Teacher t= new Teacher();
t.who1();
t.who2();
Student s= new Student();
s.who1();
//s.who2();
s.who3();
CollegeStudent cs= new CollegeStudent();
cs.who1();
//cs.who2();
cs.who3();
cs.who4();
}
}