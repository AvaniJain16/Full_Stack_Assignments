class ConstructDemo{
int a;
String s;
public void ConstructDemo(){
System.out.println("Constructor is being called");
int number;
}
public static void main(String[] args){
ConstructDemo n = new ConstructDemo();
System.out.println(n.number);

}
}