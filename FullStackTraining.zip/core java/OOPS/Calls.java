abstract class Calls{
abstract void TypeOfCall();
}
class AudioCall extends Calls{
void TypeOfCall(){
System.out.println("This is an audio call.");
}
}
class VideoCall extends Calls{
void TypeOfCall(){
System.out.println("This is a video call");
}
public static void main(String[] args){
AudioCall a= new AudioCall();
a.TypeOfCall();

}
}
