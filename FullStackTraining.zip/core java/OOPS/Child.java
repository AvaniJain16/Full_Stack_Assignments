interface Father{
void look();
}
class Baby{}
interface Mother implements Baby{
void Personality();
}
class Child implements Father,Mother{
public void look(){
System.out.println("Child got looks from Father");
}
public void Personality(){
System.out.println("Child got personality from Mother");
}
public static void main(String[] args){
Child c= new Child();
c.look();
c.Personality();
}

}