abstract class GeneralBank{    
abstract double getSavingsInterestRate(); 
abstract double getFixedDepositInterestRate();   
}    
class SBIBank extends GeneralBank{    
double getSavingsInterestRate(){return 4;} 
double getFixedDepositInterestRate(){return 7;}  
}    
class ICICIBank extends GeneralBank{    
double getSavingsInterestRate(){return 4;} 
double getFixedDepositInterestRate(){return 8.5;}  
}    
    
class TestBank{    
public static void main(String args[]){ 
ICICIBank i= new ICICIBank();   
SBIBank s= new SBIBank();  
System.out.println("Savings Interest rate of ICICI bank is " +i.getSavingsInterestRate() +"% and of SBI bank is " +s.getSavingsInterestRate() +"%" );    
 System.out.println("Fixed Deposit Interest rate of ICICI bank is " +i.getFixedDepositInterestRate() +"% and of SBI bank is " +s.getFixedDepositInterestRate() +"%" );   
}}    