class Fruit{
String Name;
String Taste;
String Size;
void eat(String Name,String Taste){
this.Name= Name;
this.Taste=Taste;
System.out.println(Name+ "is" +Taste +"in taste.");
}
}
class Apple extends Fruit{
void eat(String Name, String Taste){
Name="Apple";
this.Taste=Taste;
System.out.println(Name+ "is" +Taste +"in taste.");
}
}
class Orange extends Fruit{
void eat(String Name, String Taste){
Name="Orange";
this.Taste=Taste;
System.out.println(Name+ "is" +Taste +"in taste.");
}
}
class FruitTest{
Fruit f= new Fruit();
f.eat("fruit", "variable");
Apple a= new Apple();
a.eat()
}