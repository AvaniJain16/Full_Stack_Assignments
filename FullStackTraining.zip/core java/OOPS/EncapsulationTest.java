class EncapsulationDemo{
private String Name;
private int Age;
public void setName(String Name){
this.Name= Name;
}
public String getName(){
return Name;
}
public void setAge(int Age){
this.Age= Age;
}
public int getAge(){
return Age;
}
}
class EncapsulationTest{
public static void main(String[] args){
EncapsulationDemo d= new EncapsulationDemo();
d.setName("Yash");
d.setAge(23);
System.out.println(d.getName());
}
}