class Employee{
private int emp_id;
public void setEmpId(int emp_id){
this.emp_id=emp_id;
}
public int getEmpId(){
return emp_id;
}
}
class Organization{
public static void main(String[] args){
Employee e= new Employee();
e.setEmpId(1001);
System.out.println(e.getEmpId());

}
}