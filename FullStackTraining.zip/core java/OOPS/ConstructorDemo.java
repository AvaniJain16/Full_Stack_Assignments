class ConstructorDemo{
String Name;
int Age;
ConstructorDemo(String Name,int Age){
this.Name=Name;
this.Age=Age;
}
public static void main(String[] args){
ConstructorDemo c= new ConstructorDemo("Yash",23);
System.out.println(c.Name);
}
}