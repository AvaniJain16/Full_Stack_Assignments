interface IndianFood {
    void indianFood();
}
interface ChineseFood {
    void chineseFood();
}
class Food implements IndianFood, ChineseFood {
    public void indianFood() {
      System.out.println("These are Indian food ");
   }
    public void chineseFood() {
      System.out.println("These are Chinese food");
	}
}
 class Demo {
   public static void main(String args[]) {
      Food a = new Food();
      a.indianFood();
      a.chineseFood();
   }
}