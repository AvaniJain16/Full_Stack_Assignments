import java.io.Console;
class ConsoleDemo{
public static void main(String[] args){
String s;
char c[];
Console ob= System.console();
System.out.print("Enter Username:");
s =ob.readLine();
System.out.print("Enter Password:");
c= ob.readPassword();
String a= String.valueOf(c);
System.out.println("Username" +s +"Password" +c);
System.out.println("Actual password:" +a);


}
}
