import java.time.LocalDate;  
import java.time.DayOfWeek;
import java.time.temporal.ChronoField;  
import java.util.Scanner;

public class DayOfWeekUsingApi {  
  public static void main(String[] args) {  
	Scanner sc = new Scanner(System.in);
    System.out.println("Enter any year: ");
    int year = sc.nextInt();
	System.out.println("Enter any month: ");
    int month = sc.nextInt();
	System.out.println("Enter any date: ");
    int date = sc.nextInt();
    LocalDate localDate = LocalDate.of(year, month, date);  
    DayOfWeek dayOfWeek = DayOfWeek.from(localDate);  
    System.out.println(dayOfWeek.name());  
    System.out.println(dayOfWeek.get(ChronoField.DAY_OF_WEEK));  
  }  
}  