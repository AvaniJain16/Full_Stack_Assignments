class ReturnInst{  
ReturnInst reply(){ 
System.out.println("hello");
return this;  
} 
 System.out.println("yash tech");
}  
class ReturnInstDemo{  
public static void main(String args[]){  
new ReturnInst().reply();  
}  
}  