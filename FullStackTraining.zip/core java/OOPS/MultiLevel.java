class MultiLevel{
void inherit1(){
System.out.println("Inheriting first");}
}
class Child1 extends MultiLevel{
void inherit2(){
System.out.println("Inheriting second");
}}
class Child2 extends Child1{
void inherit3(){
System.out.println("Child");
}
public static void main(String[] args){
Multilevel m= new MultiLevel();
m.inherit1();
Child1 c1= new Child1();
c1.inherit1();
c1.inherit2();
Child2 c2= new Child2();
c2.inherit1();
c2.inherit2();
c2.inherit3();

}
}