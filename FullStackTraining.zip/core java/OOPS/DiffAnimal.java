class DiffAnimal{  
void eat(){System.out.println("Animal is eating");}}  
class Dog extends Animal{  
void eat(){System.out.println("Dog is eating");}}  
class Cat extends Animal{  
void eat(){System.out.println("Cat is eating");}}
class Test{  
public static void main(String args[]){  
Animal a= new Animal(); 
Dog d= new Dog();
Cat c= new Cat(); 
 a.eat();
 d.eat();
 c.eat();
}  
}  