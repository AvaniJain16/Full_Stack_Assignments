package testPackage;
public class Foundation{
private int var1;
 int var2;
public int var3;
protected int var4;
}