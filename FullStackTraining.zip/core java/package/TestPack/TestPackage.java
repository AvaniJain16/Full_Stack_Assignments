import testPackage.Foundation;

public class TestPackage {

	public static void main(String[] args) {
		Foundation foundation = new Foundation();
        //foundation.var1 = 57;
		foundation.var2 = 89;
		//foundation.var3 = 5;
		//foundation.var4 = 8;
		//System.out.println(foundation.var1);
		System.out.println(foundation.var2);
		//System.out.println(foundation.var3);
		//System.out.println(foundation.var4);
	}

}