import ppackage.Animal;
class Dog{
public static void main(String[] args){
Animal dog= new Animal();
dog.eat();
dog.sleep();
dog.walk();
}

}