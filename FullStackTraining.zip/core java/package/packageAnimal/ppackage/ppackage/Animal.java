package ppackage;
public class Animal{
public void eat(){
System.out.println("Eating..");
}
public void sleep(){
System.out.println("Sleeping..");
}
public void walk(){
System.out.println("Walking..");
}
}