package com.automobile.TwoWheeler;
import com.automobile.Vehicle;
public class Hero extends Vehicle {
public int getSpeed() {
System.out.println("Current speed");
}
public void radio() {
System.out.println("Radio Device");
}}}