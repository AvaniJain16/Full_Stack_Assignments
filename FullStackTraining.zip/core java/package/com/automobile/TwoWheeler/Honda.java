package com.automobile.TwoWheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle  {
public int getSpeed() {
System.out.println("Current speed");
}
public void cdplayer() {
System.out.println("cdplayer");
}}}