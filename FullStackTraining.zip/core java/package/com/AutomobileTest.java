package com.automobile;
import automobile.TwoWheeler.Hero;
import automobile.TwoWheeler.Honda;


public class AutomobileTest {

	public static void main(String[] args) {
		Hero hero = new Hero();
		System.out.println(hero.getSpeed());
	
	}

}