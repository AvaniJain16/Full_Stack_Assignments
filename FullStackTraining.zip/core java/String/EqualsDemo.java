class EqualsDemo{
public static void main(String[] args){
String s1 = new String("yash");
String s2 = new String("yash");
System.out.println(s1.equals(s2));
String s3="hey";
String s4="hey";
System.out.println(s3.equals(s4));
}
}