class PalindromeCheck
{
   public static void main(String args[])
   {
     int i=0;
	 String s="",rev="";
     while(i<args.length)
    {
     s = args[i];
     System.out.println(s);
      i++;
    }
 int length = s.length();
      for ( int j=length-1; j >= 0; j-- )
         rev = rev + s.charAt(j);
      if (s.equals(rev))
         System.out.println(s+" is a palindrome");
      else
         System.out.println(s+" is not a palindrome"); 
   }
}