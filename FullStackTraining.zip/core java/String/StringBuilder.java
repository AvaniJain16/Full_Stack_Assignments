class StringBuilderDemo
{
   public static void main(String args[])
   {
   
   StringBuilder sb1= new StringBuilder("yash");
   StringBuilder sb2= new StringBuilder("tech");
   System.out.println(sb1.append(sb2));
    System.out.println(sb2.capacity());
    System.out.println(sb1.charAt(2));
	 System.out.println(sb1.equals(sb2));
	  System.out.println(sb2.reverse());
	   System.out.println(sb2.replace(2,5,"aa"));
	   sb2.trimToSize();
	   }}