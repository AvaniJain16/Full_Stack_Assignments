class CompareToDemo{
public static void main(String[] args){
String s1 = new String("yash");
String s2 = new String("YasH");
System.out.println(s1.compareTo(s2));
}
}