class IsEmptyDemo{
public static void main(String[] args){
String s = new String("yash");
System.out.println(s.isEmpty());
}
}