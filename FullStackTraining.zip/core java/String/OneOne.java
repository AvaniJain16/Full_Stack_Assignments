class OneOne
{
   public static void main(String args[])
   {
     int i=0,j=0;
	 String x="",y="";
StringBuilder result= new StringBuilder();
     while(i<args.length)
    {
     x = args[i];
     System.out.println(x);
      i++;
    }
	 while(j<args.length)
    {
     y = args[j];
     System.out.println(y);
      j++;
    }
for (int k = 0; k < x.length() || k < y.length(); k++) {
            if (k < x.length())
                result.append(x.charAt(k));
            if(k < y.length())
                result.append(y.charAt(k-1));}
System.out.println(result);
}}	