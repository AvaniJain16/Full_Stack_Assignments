class TrimDemo{
public static void main(String[] args){
String s = new String("yash");
//System.out.println(s.trim(0,1));
s=s.trim(0,2);
System.out.Println(s);
}
}