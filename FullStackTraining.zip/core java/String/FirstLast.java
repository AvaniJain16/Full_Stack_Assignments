class FirstLast {
	
	public static void main(String args[])
	{
		int i=0;
	 String s="";
     while(i<args.length)
    {
     s = args[i];
     System.out.println(s);
      i++;
    }
		s = s.substring(1, s.length() - 1);
		System.out.print(s);
	}
}
