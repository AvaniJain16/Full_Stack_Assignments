class EqualsIgnoreDemo{
public static void main(String[] args){
String s1 = new String("yash");
String s2 = new String("YasH");
System.out.println(s1.equalsIgnoreCase(s2));
String s3="hey";
String s4="Heey";
System.out.println(s3.equalsIgnoreCase(s4));
}
}