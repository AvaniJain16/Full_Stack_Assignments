class StringEvenOdd{
public static void main(String[] args){
 int i=0;
	 String s="",rev="";
     while(i<args.length)
    {
     s = args[i];
     System.out.println(s);
      i++;
    }
	int length=s.length();
	if(length%2==0)
	System.out.println(s.substring(0,length/2));
	else
	System.out.println("NULL");
}
}