class MathOperation {
public static void main(String[] args){
try{
int a,b,c,d,e;
a=args[0];
b=args[1];
c=args[2];
d= args[3];
e=args[4];
int arr[]= {a,b,c,d,e};
for(int i=0;i<5;i++){
int sum= sum+arr[i];
}
int avg=sum/5;
System.out.println("The sum is: " +sum);
System.out.println("The average is: " +avg);
}
catch(Exception e){
System.out.println(e);
}

}
}