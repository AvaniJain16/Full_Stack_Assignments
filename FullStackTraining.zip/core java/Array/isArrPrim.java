class math{}
class array{
int arr[]={1,2,3,4,5};
}
public class isArrPrim {  
   public static void main(String[] args) throws Exception {   
      Class c1 = Class.forName("math");
       System.out.println( c1.isPrimitive());  
	    Class c2 = Class.forName("array");
		
       System.out.println( c2.isArray()); 
      }  
   }  