import java.io.FileInputStream;
import java.io.IOException;

class CountVowel{
public static void main(String[] args) throws IOException{
int a=0,e=0,i=0,o=0,u=0,total=0;
int r;
FileInputStream f = new FileInputStream("d:/yash/abc.txt");
while((r=f.read())!=-1){
if((char)r=='a' || (char)r=='A'){
++a;
++total;
}
if((char)r=='e' || (char)r=='E'){
++e;
++total;
}
if((char)r=='i' || (char)r=='I'){
++i;
++total;
}
if((char)r=='o' || (char)r=='O'){
++o;
++total;
}
if((char)r=='u' || (char)r=='U'){
++u;
++total;
}
}
System.out.println("Total number of vowels in file are: " +total);
System.out.println("Number of times a occur is: " +a);
System.out.println("Number of times e occur is: " +e);
System.out.println("Number of times i occur is: " +i);
System.out.println("Number of times o occur is: " +o);
System.out.println("Number of times u occur is: " +u);
}
}