import java.io.ByteArrayInputStream; 
import java.io.IOException;
	public class ByteArrayInputDemo 
	{  
		public static void main(String[] args) throws IOException
		{  
		byte[] b = { 97, 36, 37, 38 };  
		ByteArrayInputStream byt = new ByteArrayInputStream(b);  
		int k ;  
		while ((k = byt.read()) != -1) 
		{  
			char ch = (char) k;  
			System.out.println("ASCII value of Character is:" + k + "; Special character is: " + ch);  
		}  
		}  
	}  