import java.io.BufferedReader;
import java.io.InputStreamReader;
class BuffReadDemo{
public static void main(String args[])throws Exception{             
    InputStreamReader i=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(i);            
    System.out.println("Enter your name");    
    String name=br.readLine();    
    System.out.println("Hello "+name);    
}    
}