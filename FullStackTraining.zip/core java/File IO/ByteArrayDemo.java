import java.io.*;  
public class ByteArrayDemo {  
  public static void main(String[] args) throws IOException {  
   FileInputStream in= new FileInputStream("d:/yash/xyz.txt"); 
    ByteArrayInputStream byt = new ByteArrayInputStream(in);  
    int k = 0;  
    while ((k = byt.read()) != -1) {  
      char ch = (char) k;  
      System.out.println("ASCII value of Character is:" + k + "; Special character is: " + ch);  
    }  
  }  
}  