import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
public class InFileDemo 
{   
    public static void main(String[] args) 
    {
        BufferedReader r = null;
        int charCount = 0;
        int wordCount = 0;        
        int lineCount = 0; 
        int spaceCount = 0;
        try
        {
            r = new BufferedReader(new FileReader("d:/yash.txt"));
            String currentLine = r.readLine();             
            while (currentLine != null)
            {              
                lineCount++;             
                String[] w = currentLine.split(" ");
                wordCount = wordCount + w.length;
                for (String word : w)
                {
                    charCount = charCount + word.length();
					spaceCount= spaceCount+wordCount-1;
                }
              currentLine = r.readLine();
            }
            System.out.println("Number Of Chars In File : "+charCount);          
            System.out.println("Number Of Words In File : "+wordCount);             
            System.out.println("Number Of Lines In File : "+lineCount);
			System.out.println("Number Of Spaces In File : "+spaceCount);
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                r.close();				
            }
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
    }   
}