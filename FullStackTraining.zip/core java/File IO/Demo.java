import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;
class Demo{
public static void main(String[] args){
try{
FileInputStream in1= new FileInputStream("d:/yash/xyz.txt");
FileInputStream in2= new FileInputStream("d:/yash/abc.txt");
SequenceInputStream s= new SequenceInputStream(in1,in2);
int c;
while((c= s.read())!=-1){
out.write(c);
}
s.close();
in1.close();
in2.close();}
catch(Exception e){
	System.out.println(e);
}

}
}