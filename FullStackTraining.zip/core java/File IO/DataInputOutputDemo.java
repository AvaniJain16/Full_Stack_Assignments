import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
public class DataInputOutputDemo {
	public static void main(String[] args) {
		FileOutputStream fout = null;
		DataOutputStream dout = null;
		try {
			fout=new FileOutputStream("d:/yash/abc.txt");
			dout=new DataOutputStream(fout);
			dout.writeInt(50);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(fout!=null){
					fout.close();
				}
				if(dout!=null){
					dout.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		FileInputStream fin = null;
		DataInputStream din = null;
		try {
			fin = new FileInputStream("d:/yash/abc.txt");
			din = new DataInputStream(fin);
			System.out.println(din.readInt());
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(fin!=null){
					fin.close();
				}
				if(din!=null){
					din.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
 