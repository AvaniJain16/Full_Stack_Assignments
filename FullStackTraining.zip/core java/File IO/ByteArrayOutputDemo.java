import java.io.ByteArrayOutputStream;

class ByteArrayOutputDemo {
  public static void main(String[] args) {

    String data = "Yash Tech";

    try {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] a = data.getBytes();
      out.write(a);
      out.close();
    }

    catch(Exception e) {
      e.getStackTrace();
    }
  }
}