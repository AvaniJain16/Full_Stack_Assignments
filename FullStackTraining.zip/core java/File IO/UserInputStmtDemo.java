import java.sql.*;
import java.util.*;
class UserInputStmtDemo{
public static void main(String[] args){
	BufferedReader br=new BufferedReader(i);            
    System.out.println("Enter EmpID: ");    
    String empId=br.readLine();
	 System.out.println("Enter EmpName: ");    
    String empName=br.readLine();
	try{
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/Yash";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	PreparedStatement stmt=con.prepareStatement("insert into Employee values(?,?)");  
    stmt.setInt(1,empId); 
    stmt.setString(2,empName);	
  
    int i=stmt.executeUpdate();  
    System.out.println(i+" records inserted");  
	con.close();
	}
	catch(Exception e){
		System.out.println(e);
	}

}
}