import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;
class CountLetter
{
	public static void main(String[] args) throws IOException
	{
	Scanner in = new Scanner(System.in);
	System.out.println("Enter the file name: ");
	String input = in.nextLine();
	File file = new File(input);
	FileInputStream f = new FileInputStream(file);
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the character to be counted: ");
	char ch = s.next().charAt(0);
	int i,count=0;
	while((i=f.read())!=-1)
		{
		if(i==(int)ch)
			count++;
		if(i-(int)ch==32 || i-(int)ch==-32)
			count++;
		
		}
		System.out.println("File " +file +" has " +count +" instances of letter " +ch);
	}	
	
}