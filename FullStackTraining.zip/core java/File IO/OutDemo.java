import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class OutDemo{
public static void main(String[] args){
	FileOutputStream in= null;
	BufferedOutputStream out= null;
try{
in= new FileOutputStream("d:/yash/abc.txt");
out= new BufferedOutputStream(in);
int c=12;
out.write(c);
            out.close();

}
catch(Exception e){
	e.getMessage();
	
}


}
}