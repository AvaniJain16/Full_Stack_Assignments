import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class DataOutputDemo {
	public static void main(String[] args) {
		FileOutputStream f = null;
		DataOutputStream d = null;
		try {
			f=new FileOutputStream("d:/yash/abc.txt");
			d=new DataOutputStream(f);
			d.writeInt(50);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(f!=null){
					f.close();
				}
				if(d!=null){
					d.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}}