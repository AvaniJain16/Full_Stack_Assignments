import java.io.FileInputStream;

class Checked {
	public static void main(String args[]) {
	try{
		FileInputStream f
			= new FileInputStream("/Desktop/xyz.txt");
			}
	catch(Exception e){
	System.out.println(e);
	}	
	
	}
}
