class UncheckExcep
{
public static void main(String[] args){
int arr1[]={2,3,5};
String s1=null;
String s2="Yash";
try{
int arr2[]=new int[-2];
}
catch(Exception e1){
	e1.printStackTrace();
}
try{
System.out.println(arr1[4]);
}
catch(Exception e2){
	e2.printStackTrace();
}
try{
System.out.println(s1.equals("Yash"));
}
catch(Exception e3){
	e3.printStackTrace();
}
try{
System.out.println(s2.charAt(5));
}
catch(Exception e4){
	e4.printStackTrace();
}
try{
System.out.println(20/0);
}
catch(Exception e5){
	e5.printStackTrace();
}
}
}