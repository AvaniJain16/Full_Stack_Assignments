import java.io.FileInputStream;
import java.io.IOException;
class CheckExcep
{
	public static void main(String[] args) throws IOException
	{
			FileInputStream f = new FileInputStream("pqr.txt");
			Class.forName("com.automobile.xyz");
			
	}
}