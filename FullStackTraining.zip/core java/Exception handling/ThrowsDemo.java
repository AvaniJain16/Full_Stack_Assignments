import java.io.FileInputStream;
import java.io.FileNotFoundException;
class ThrowsD
{
void show(int x,int y) throws FileNotFoundException,ArithmeticException
{
x=a;
y=b;

System.out.println(x/y);
}
}
class ThrowsDemo
{
public static void main(String[] args)
{
int a=10,b=0;
ThrowsD t=new ThrowsD();
try
{
t.show(a,b);
}
catch(FileNotFoundException e)
{
e.printStackTrace();
}
catch(ArithmeticException f)
{
f.printStackTrace();
}
System.out.println("Normal Termination");
}}