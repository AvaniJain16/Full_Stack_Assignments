class Sum{}
class ClassDemo {
void printName(Object obj){  
  Class c=obj.getClass();    
  System.out.println(c.getClass("Sum"));  
  }
   public static void main(String[] args) {
      try {
         Class c1 = Class.forName("ClassDemo");
         ClassLoader cLoad = c1.getClassLoader();  
		 System.out.println(c2.getName()); 
		 Sum s=new Sum();  
         ClassDemo c2=new ClassDemo();  
   c2.printName(s);  
          } 
      catch(ClassNotFoundException ex) {
         System.out.println(ex.toString());
      }
   }
}