import java.util.Scanner;
class ValueOutOfRange extends Exception{
ValueOutOfRange(String s){
super(s);
}
}
class StudentMarks{
public static void main(String[] args ){
String std1, std2; 
Scanner sc=new Scanner(System.in);  
System.out.println("Enter the name of first student: " +std1); 
std1=sc.nextInt(); 
System.out.println("Enter the name of first student: " +std2); 
std2=sc.nextInt(); 
int arr1[], arr2[];
try{
for(int i=0;i<3;i++){
arr1[i]=Integer.parseInt(args[i]);
}
for(int i=0;i<3;i++){
arr2[i]=Integer.parseInt(args[i]);
}
if (0<arr1[0]<101||0<arr1[1]<101||0<arr1[2]<101||0<arr2[0]<101||0<arr1[0]<101||0<arr1[0]<101||0<arr1[0]<101)
}
}}