import java.lang.IllegalAccessException;
class ThrowsExcep
{
	static void display() throws IllegalAccessException
	{
		System.out.println("Inside Display method..");
		throw new IllegalAccessException();
	}
	public static void main(String[] args)
	{
		try
		{
			display();
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
		}
	}
}
