import java.util.Scanner;  
public class ArrayInput   
{  
public static void main(String[] args)   
{  
int n;  
Scanner sc=new Scanner(System.in);  
System.out.print("Enter the number of elements you want to store: ");    
n=sc.nextInt();    
int[] array = new int[n];  
System.out.println("Enter the elements of the array: ");  
for(int i=0; i<n; i++)  
{   
array[i]=sc.nextInt();  
} 
try{
int ind;  
Scanner scn=new Scanner(System.in);  
System.out.print("Enter the Index of number you want to print: ");    
ind=scn.nextInt(); 
System.out.println(array[ind]);
} 
catch(Exception e){
System.out.println(e);
}
}  
}  


