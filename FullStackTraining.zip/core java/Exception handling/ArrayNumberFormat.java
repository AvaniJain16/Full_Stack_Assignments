import java.util.Scanner;  
public class ArrayNumberFormat 
{  
public static void main(String[] args)   
{  
int n;  
Scanner sc=new Scanner(System.in);  
System.out.print("Enter the number of elements you want to store: ");    
n=sc.nextInt();  
try{  
 Scanner scn1 = new Scanner(System.in);
        int num = scn1.nextInt();
        scn1.nextLine();
        int[] array = new int[num];
        String [] tokens = scn1.nextLine();

        for (int i=0; i<tokens.length;i++){
            array[i]=Integer.parseInt(tokens[i]);
        }
int ind;  
Scanner scn=new Scanner(System.in);  
System.out.print("Enter the Index of number you want to print: ");    
ind=scn.nextInt(); 
System.out.println(array[ind]);
} 
catch(Exception e){
System.out.println(e);
}
}  
}  
 