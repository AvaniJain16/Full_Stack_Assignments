class ExceptionFinally{
public static void main(String[] args){
System.out.println("yash");
try{
System.out.println(100/0);
}
catch(Exception e){
	System.out.println(e);
}
finally{
System.out.println("tech");
}
}}