import java.util.Scanner;

public class Regex2 {
 
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in); 
		System.out.print("Enter a string: ");  
		String str= sc.nextLine(); 
        String[] splits = str.split("\\s");
        for(String splits2: splits) {
            System.out.println(splits2);
			
			
        }
 
    }
 
}