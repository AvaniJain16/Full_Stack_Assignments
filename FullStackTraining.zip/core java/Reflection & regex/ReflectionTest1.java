class ClassDemo {

   public static void main(String[] args) {

      try {
         Class cls = Class.forName("ClassDemo");    
         System.out.println("Class = " + cls.getName());
	  }
      catch(ClassNotFoundException ex) {
         System.out.println(ex.toString());
      }
   }
}