import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class RegDemo {

    public static void main(String[]args) {
	Scanner sc= new Scanner(System.in); 
	System.out.print("Enter a mobile number: ");  
	String number= sc.nextLine();
      Pattern pattern = Pattern.compile("/^([+]\\d{2}[ ])?\\d{10}$/");
      Matcher matcher = pattern.matcher(number);
      if(matcher.matches()) {
         System.out.println("Given phone number is valid");
      } else { 
         System.out.println("Given phone number is not valid");
	  }
	
    }
    }
