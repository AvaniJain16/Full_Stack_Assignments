import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpecificRegex {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter your Phone number: ");
      String phone = sc.next();
      Pattern pattern1 = Pattern.compile("\\d{10}");
      Matcher matcher1 = pattern1.matcher(phone);
      if(matcher1.matches()) {
         System.out.println("Given phone number is valid");
      } else { 
         System.out.println("Given phone number is not valid");
      }
	   System.out.println("Enter your Email id: ");
      String email = sc.next();
      Pattern pattern2 = Pattern.compile("(.*)(@)(.*)(.[a-z])");
      Matcher matcher2 = pattern2.matcher(email);
      if(matcher2.matches()) {
         System.out.println("Given Email id is valid");
      } else { 
         System.out.println("Given Email id is not valid");
      }
   }
}