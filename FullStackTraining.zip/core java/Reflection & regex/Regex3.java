import java.util.Scanner;

public class Regex3 {

	int isPrime(n){
	const regex = /^1?$|^(11+?)\1+$/;
	return!('1'.repeat(n).match(regex));
	}
 
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in); 
		System.out.print("Enter a number: ");  
		int i= sc.nextInt(); 
		isPrime();
       
			
			
        }
 
    }
 
