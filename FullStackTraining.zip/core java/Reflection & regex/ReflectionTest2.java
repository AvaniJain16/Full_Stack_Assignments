class SumClass{}

class ReflectionTest2{ 
  void printName(Object obj){  
  Class cl=obj.getClass();    
  System.out.println(cl.getClass("SumClass"));  
  }  
  public static void main(String args[]){  
   SumClass s=new SumClass();  
   
   ReflectionTest2 r=new ReflectionTest2();  
   r.printName(s);  
 }  
}  
