import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class Regex1 {

    public static void main(String[]args) {
	Scanner sc= new Scanner(System.in); 
	System.out.print("Enter a string: ");  
	String str= sc.nextLine(); 
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(str);
        while(m.find()) {
            System.out.print(m.group());
        }
    }
}