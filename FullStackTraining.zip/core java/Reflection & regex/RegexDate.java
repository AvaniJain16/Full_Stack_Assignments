import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class RegexDate {

    public static void main(String[]args) {
	Scanner sc= new Scanner(System.in); 
	System.out.print("Enter Date: ");  
	String date= sc.nextLine(); 
        Pattern pattern1 = Pattern.compile("^\\d{2}-\\d{2}-\\d{4}$");
      Matcher matcher1 = pattern1.matcher(date);
	   Pattern pattern2 = Pattern.compile("^\\d{2}/\\d{2}/\\d{4}$");
      Matcher matcher2 = pattern2.matcher(date);
	   Pattern pattern3 = Pattern.compile("^\\d{2}.\\d{2}.\\d{4}$");
      Matcher matcher3 = pattern3.matcher(date);
      if(matcher1.matches() || matcher2.matches() || matcher3.matches() ) {
         System.out.println("Given date format is valid");
      } else { 
         System.out.println("Given date format is not valid");
      }
        
    }
}