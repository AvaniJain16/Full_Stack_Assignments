class SumClass{
int a=10;
int b=20;
int c=a+b;
System.out.println(c);
}    
    
public class ReflectionTest1{    
 public static void main(String args[]) throws Exception {    
  Class cl=Class.forName("SumClass");    
  System.out.println(cl.getName());    
 }    
}    