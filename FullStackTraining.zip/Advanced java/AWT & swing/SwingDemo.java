import javax.swing.JButton; 
import javax.swing.JLabel;
import javax.swing.JFrame; 
import javax.swing.JTextArea; 
import javax.swing.JCheckBox; 

public class SwingDemo {  
public static void main(String[] args) {  
    JFrame f=new JFrame("Button");  
    JButton b=new JButton("Done");  
    b.setBounds(50,130,100,30);  
    f.add(b);  
    f.setSize(400,400);  
    f.setLayout(null);  
    f.setVisible(true);  
    JLabel l1;  
    l1=new JLabel("Test");  
    l1.setBounds(50,50, 100,30);  
    f.add(l1); 
    f.setSize(300,300);  
    f.setLayout(null);  
    f.setVisible(true);
	 JTextArea area=new JTextArea("Write your answer here");  
        area.setBounds(50,75, 120,30);  
        f.add(area);  
        f.setSize(500,500);  
        f.setLayout(null);  
        f.setVisible(true);  
		  JCheckBox checkBox = new JCheckBox("Rechecked", true);  
        checkBox.setBounds(50,105, 130,30);  
        f.add(checkBox);  
        f.setSize(400,400);  
        f.setLayout(null);  
        f.setVisible(true);  

}  
}  