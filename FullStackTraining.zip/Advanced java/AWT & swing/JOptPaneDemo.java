import javax.swing.*;  
public class JOptPaneDemo {   
JOptPaneDemo(){  
    JFrame f=new JFrame(); 
    JOptionPane.showMessageDialog(f,"Yash");  
}  
public static void main(String[] args) {  
    new JOptPaneDemo();  
}  
}  