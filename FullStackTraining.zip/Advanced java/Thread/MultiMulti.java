class MultiMulti1 extends Thread  
{  
    public void run()  
    {  
        System.out.println("First execution started");  
    }  
}  
class MultiMulti2 extends Thread  
{  
    public void run()  
    {  
        System.out.println("Second execution started");  
    }  
}  
class MultiMulti 
{  
    public static void main(String args[])  
    {  
        MultiMulti1 M1 = new MultiMulti1();  
        MultiMulti2 M2 = new MultiMulti2();  
        M1.start();  
        M2.start();  
    }  
}  