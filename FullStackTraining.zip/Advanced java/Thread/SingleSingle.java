class SingleSingle extends Thread{  
 public void run(){  
   System.out.println("Execution started");  
 }  
 public static void main(String args[]){  
  SingleMulti t=new SingleMulti();  
  t.start();  
 
 }  
}  