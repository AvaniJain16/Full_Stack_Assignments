public class DaemonYieldDemo extends Thread{  
 public void run(){  
  if(Thread.currentThread().isDaemon()){  
	System.out.println("Daemon thread working");  
  }  
  else{  
	System.out.println("Non daemon thread working");  
 }  
 }  
 public static void main(String[] args){  
	DaemonYieldDemo t1=new DaemonYieldDemo(); 
	DaemonYieldDemo t2=new DaemonYieldDemo();  
	t1.setDaemon(true); 
		Thread.yield();
	t1.start();  
	t2.start();   
 }  
}  