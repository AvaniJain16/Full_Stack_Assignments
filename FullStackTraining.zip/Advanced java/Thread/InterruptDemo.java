class InterruptDemo extends Thread  
{  
    public void run()  
    {  
	System.out.println(Thread.interrupted());
	//System.out.println(Thread.currentThread().isInterrupted());
       try{
	   for(int i=0;i<4;i++){
	   System.out.println(i);
	    System.out.println(Thread.interrupted());
	   Thread.sleep(2000);
	   System.out.println(Thread.interrupted());
	//System.out.println(Thread.currentThread().isInterrupted());
	   }
	   } 
	   catch(Exception e){
	   System.out.println(e);
	   }
    }  
  
    public static void main(String args[])  
    {  
        InterruptDemo d = new InterruptDemo();  
        d.start();  
        d.interrupt(); 
    }  
	}
  