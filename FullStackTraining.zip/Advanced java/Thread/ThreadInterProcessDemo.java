class Revenue extends Thread{
int total;
void seats(){
synchronized(this){
for(int i=1;i<6;i++){
total=total+400;
}
}
this.notify();
}
}
public class ThreadInterProcessDemo{
public static void main(String[] args) throws Exception{
Revenue r= new Revenue();
r.start();
//System.out.println(r.total);
synchronized(r){
r.wait();
System.out.println("Total amount: " +r.total);
}
}
}