import java.io.FileInputStream; 
import java.io.FileOutputStream; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream;
import java.io.File; 
import java.io.Serializable;
import java.lang.Throwable; 
 
  class Employee implements Serializable{
    private String Name;
    private String Department;
	private String Designation;
    private double Salary;
	
	Employee(){
	System.out.println("No argument constructor");
	}
	
	Employee(String Name, String Department, String Designation, double Salary) {                          
    this.Name = Name;                                                             
    this.Department = Department;
	this.Designation = Designation;	
    this.salary = salary;                                                         
	}   

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getDepartment() {
        return Department;
    }
	
	public void setDesignationt(String Designation) {
        this.Designation = Designation;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setSalary(double Salary) {
            this.Salary = Salary;
    }

    public double getSalary() {
        return Salary;
    }
	
	 public String toString() {                                                     
     return "Name=" + Name + ", Department=" + Department  + ", Designation=" + Designation + ", Salary=" + Salary;                  
 }                                                                              
} 

 public class GetSetConstructDeserialize {                                                
 public static void main(String args[]) throws Exception {                                                                                                                                                               
   Employee obj1 = new Employee();                                                    
   FileOutputStream fout = new FileOutputStream("d:/yash/abc.txt");                  
   ObjectOutputStream oout = new ObjectOutputStream(fout);                      
   oout.writeObject(obj1);                                                       
   oout.flush();                                                                
   oout.close();                                                                
                                                                                                                                                                                                                                            
   FileInputStream fin = new FileInputStream("d:/yash/abc.txt");                     
   ObjectInputStream oin = new ObjectInputStream(fin);                          
   Employee obj2 = (Employee)oin.readObject();                                   
   oin.close();                                                                 
   System.out.println("Employee Object: " + obj2);                               
                                                                              
}  }                                                                               
