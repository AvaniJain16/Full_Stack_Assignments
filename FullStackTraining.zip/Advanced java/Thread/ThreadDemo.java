class MultiMulti1 extends Thread  
{  
    public void run()  
    {  
	 if(Thread.currentThread().isDaemon()){  
	System.out.println("Daemon thread working");  
  }  
  else{  
	System.out.println("Non daemon thread working");  
 } 
        System.out.println("First execution started");  
    }  
}  
class MultiMulti2 extends Thread  
{  
    public void run()  
    {  
	try{
		Thread.sleep(5000);
		}
	catch(Exception e){
	    System.out.println(e);
	}	
        System.out.println("Second execution started"); 
		System.out.println("The priority value of m2 thread is " +Thread.currentThread().getPriority());
    }  
}  
class ThreadDemo
{  
    public static void main(String args[])  
    {  
		System.out.println(Thread.currentThread().getName());
        MultiMulti1 m1 = new MultiMulti1();
		MultiMulti1 m11 = new MultiMulti1();
		m1.setName("m1 Thread");
		System.out.println("Is the m1 thread alive?      " +m1.isAlive());
        MultiMulti2 m2 = new MultiMulti2();  
		m2.setName("m2 Thread");
		m1.setDaemon(true); 
        m1.start();  
		System.out.println("Is the m1 thread alive now?  " +m1.isAlive());
		m2.setPriority(4);
        m2.start(); 
		m11.start();		
    }  
}  