class SingleMulti extends Thread{  
 public void run(){  
   System.out.println("Execution started");  
 }  
 public static void main(String args[]){  
  SingleMulti t1=new SingleMulti();  
  SingleMulti t2=new SingleMulti();  
  SingleMulti t3=new SingleMulti();  
  
  t1.start();  
  t2.start();  
  t3.start();  
 }  
}  