class Thread1 extends Thread  
{  
    public void run()  
    {  
		    Thread.State state1 = Thread.currentThread().getState(); 
        System.out.println("First execution started");  
		   System.out.println("State of thread: " + state1); 
    }  
}  
class Thread2 extends Thread  
{  
    public void run()  
    {  
		    Thread.State state2 = Thread.currentThread().getState(); 
        System.out.println("Second execution started"); 
		   System.out.println("State of thread: " + state2); 
		 try{
	   for(int i=0;i<4;i++){
	   System.out.println(i);
	   Thread.sleep(2000);
	    Thread.State state3 = Thread.currentThread().getState(); 
		      System.out.println("State of thread: " + state3); 
	   }
	   } 
	   catch(Exception e){
	   System.out.println(e);
	      
	   }
    }  
}  
class GetStateDemo
{  
    public static void main(String args[])  
    {  
        Thread1 t1 = new Thread1();  
        Thread2 t2 = new Thread2();  
        t1.start();  
        t2.start();  
		//m2.interrupt();
    }  
}  