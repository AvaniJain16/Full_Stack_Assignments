import java.util.Iterator;
import java.util.TreeSet;

class Country {
	TreeSet<String> H1 = new TreeSet<>();
	
	public TreeSet<String> saveCountryNames(String CountryName) {
		H1.add(CountryName);
		return H1;
	}
	
	public String getCountry(String CountryName) {
		Iterator<String> it = H1.iterator();
		
		while (it.hasNext()) {
			if (it.next().equals(CountryName))
				return CountryName;
		}
		
		return null;
	}
}

public class Set4 {

	public static void main(String[] args) {
		Country cntry = new Country();
		cntry.saveCountryNames("India");
		cntry.saveCountryNames("China");
		cntry.saveCountryNames("Russia");
		cntry.saveCountryNames("Nepal");
		cntry.saveCountryNames("BHutan");

		System.out.println("China: " + cntry.getCountry("China"));
		System.out.println("USA: " + cntry.getCountry("USA"));		
	}

}