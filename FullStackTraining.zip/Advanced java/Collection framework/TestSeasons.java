enum Seasons {
  SPRING(2),SUMMER(4),AUTUMN(3),WINTER(3);
  int months;
  Seasons(int months){
	  this.months=months;
  }
}
public class TestSeasons
 {
   public static void main(String args[])
   {
      for(Seasons s:Seasons.values())
		{
		System.out.println(s);
		}
			System.out.println("Springs lasts for "+Seasons.valueOf("SPRING") +"months.");
			System.out.println("Spring is at: "+Week.valueOf("SPRING").ordinal() );
	 
   }
 }