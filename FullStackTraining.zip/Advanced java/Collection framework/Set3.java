import java.util.*;

public class Set3 {

	public static void main(String[] args) {
		TreeSet<String> name = new TreeSet<>();
		name.add("Yash");
		name.add("Ritik");
		name.add("Sandeep");
		name.add("Arjun");
		Iterator<String> it1 = name.iterator();
		 System.out.println("Original order:");
		while (it1.hasNext()) {
			System.out.println(it1.next());
			}
		
		 NavigableSet<String> reverse = name.descendingSet();
            Iterator<String> it2 = reverse.iterator();
 
            System.out.println("\nReverse order:");
            while (it2.hasNext()) {
                System.out.println(it2.next());
            }
		
		Iterator<String> it3 = name.iterator();
		String query = "Purv";
		boolean result = false;
		
		while (it3.hasNext()) {
			if (it3.next().equals(query)) {
				result = true;
				break;
			}
		}
		
		if (result) {
		System.out.println("\n" +query + " exists");
		}
		else {
		System.out.println("\n" +query + " doesn't exist");
		}

	}

}