import java.util.*;
public class MapDemo1{
	static Map<Integer, String> map = new HashMap<>();

	public static void sortbykey()
	{
		ArrayList<Integer> sortedKeys= new ArrayList<Integer>(map.keySet());
		Collections.sort(sortedKeys);
		for (Integer x : sortedKeys)
			System.out.println("Key = " + x + ", Value = " + map.get(x));
	}

	public static void main(String args[])
	{
		map.put(30,"Yash");
		map.put(10,"Purv");
		map.put(40,"Sandeep");
		map.put(20,"Ritik");

		sortbykey();
	}
}
