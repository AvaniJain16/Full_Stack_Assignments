import java.util.Stack;
import java.util.Iterator;
import java.util.Enumeration;

class StackDemo {
  public static void main(String[] args) {
    Stack<String> animals= new Stack<>();
    animals.push("Dog");
    animals.push("Horse");
    animals.push("Cat");
 for(String j:animals){
	System.out.println(j);
}
    animals.pop();
  System.out.println(animals);
   Enumeration i=animals.elements();  
           while(i.hasMoreElements())  
           {  
           System.out.println(i.nextElement());  
           }

    }
}