import java.util.ArrayList;
import java.util.ListIterator;
class ListIteratorDemo{
public static void main(String[] args){
ArrayList<String> season= new ArrayList<>();
season.add("Summer");
season.add("Winter");
season.add("Autumn");
season.add("Spring");
ListIterator li= season.listIterator();
li.next();
li.next();
while(li.hasPrevious()){
System.out.println(li.previous());
}
}
}