import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class Map2 {

	public static void main(String[] args) {
		Properties property = new Properties();
		
		property.setProperty("MP", "Bhopal");
		property.setProperty("Rajasthan", "Jaipur");
		property.setProperty("UP", "Lucknow");
		property.setProperty("Gujarat","Gandhinagar");

		Set<Entry<Object, Object>> set = property.entrySet();
		Iterator<Entry<Object, Object>> it = set.iterator();
		
		while (it.hasNext()) {
			Entry<Object, Object> m = it.next();
			System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
		}
	}

}