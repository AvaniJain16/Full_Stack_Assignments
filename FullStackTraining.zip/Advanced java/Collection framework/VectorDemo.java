import java.util.Vector;
import java.util.ListIterator;
class VectorDemo{
public static void main(String[] args){
Vector<String> season= new Vector<>();
season.add("Summer");
season.add("Winter");
season.add("Autumn");
season.add("Spring");
ListIterator li= season.listIterator();
li.next();
while(li.hasPrevious()){
System.out.println(li.previous());
}
}
}