import java.util.Iterator;
import java.util.Vector;
import java.util.Enumeration;

class Employee {
	
	private String name;
	private int empid;
	private Double salary;
	
	public Employee( String name,int empid, Double salary) {
		super();
		this.name = name;
		this.empid = empid;		
		this.salary = salary;
	}	
	
	public String toString() {
		return "Employee [ name=" + name + ",empid=" + empid + ", salary=" + salary + "]";
	}
}

public class List4 {

	public static void main(String[] args) {
		Vector<Employee> detail = new Vector<>();
		
		detail.add(new Employee("Yash",1014,50000.0));
		detail.add(new Employee("Ritik",1015,45000.0));
		detail.add(new Employee("Sandeep",1016,35000.0));
		
		
		Iterator<Employee> emp = detail.iterator();
		while (emp.hasNext()) 
			System.out.println(emp.next());
		
		System.out.println("\n");
		
		Enumeration enu=detail.elements();  
           while(enu.hasMoreElements())  
           {  
           System.out.println(enu.nextElement());  
           }
		

	}

}