import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Map1 {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		
		map.put("Yash","Jain");
		map.put("Ritik","Sahu");
		map.put("Sandeep","Patidar");
		map.put("Arjun","Gupta");
		
		Set<Entry<String, String>> set = map.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> m = it.next();
			
			if (m.getKey().equals("Ritik")) {
				System.out.println("Key Ritik exists");
				break;
			}
		}
		System.out.println("\n");

		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> m = it.next();
			
			if (m.getValue().equals("Jain")) {
				System.out.println("Value Jain exists");
				break;
			}
		}
		System.out.println("\n");

		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> m = it.next();
			System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
		}
	}

}