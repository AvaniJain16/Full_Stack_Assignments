import java.util.Iterator;
import java.util.ArrayList;
class ArrayListDemo1{
public static void main(String[] args){
ArrayList<String> a = new ArrayList<>();
a.add("January");
a.add("February");
a.add("March");
a.add("April");
a.add("May");
a.add("June");
a.add("July");
a.add("August");
a.add("September");
a.add("October");
a.add("November");
a.add("December");
System.out.println(a);

Iterator i=a.iterator();
while(i.hasNext()){
	System.out.println(i.next());
}
System.out.println("\n");
for(String j:a){
	System.out.println(j);
}

}
}
