import java.util.HashSet;
import java.util.Iterator;

public class Set2 {

	public static void main(String[] args) {
		HashSet<String> name = new HashSet<>();
		
		name.add("Yash");
		name.add("Ritik");
		name.add("Sandeep");
		name.add("Arjun");
		
		Iterator<String> it = name.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}