public class Testxx {

   public static void main(String args[]) {
      String Str = new String("HASH");
      System.out.println("Hashcode for Str :" + Str.hashCode() );
   }
}