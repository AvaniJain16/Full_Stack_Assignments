import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Map3 {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		
		map.put("Yash",236574);
		map.put("Ritik",647326);
		map.put("Sandeep",746362);
		map.put("Arjun",465735);
		
		Set<Entry<String, Integer>> set = map.entrySet();
		Iterator<Entry<String, Integer>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> m = it.next();
			
			if (m.getKey().equals("Ritik")) {
				System.out.println("Key Ritik exists");
				break;
			}
		}
		System.out.println("\n");

		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> m = it.next();
			
			if (m.getValue().equals(746362)) {
				System.out.println("Value 746362 exists");
				break;
			}
		}
		System.out.println("\n");

		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> m = it.next();
			System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
		}
	}

}