import java.util.LinkedList;
import java.util.Iterator;

class LinkedListDemo {
  public static void main(String[] args){
    LinkedList<String> animals = new LinkedList<>();
    animals.add("Dog");
    animals.addFirst("Cat");
    animals.addLast("Horse");
    Iterator i=animals.iterator();
    while(i.hasNext()){
	System.out.println(i.next());
	}
    System.out.println("First Element: " + animals.getFirst());
    System.out.println("Last Element: " + animals.getLast());
    }
}