import java.util.ArrayList;
class List1{
public static void main(String[] args){
ArrayList<String> month = new ArrayList<>();
month.add("January");
month.add("February");
month.add("March");
month.add("April");
month.add("May");
month.add("June");
month.add("July");
month.add("August");
month.add("September");
month.add("October");
month.add("November");
month.add("December");
for(String j:month){
	System.out.println(j);
}
}
}