package springevent;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
   public static void main(String[] args) {
      ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("Applicationcontext.xml");
      context.start();
      App obj = (App) context.getBean("app");
      obj.getMessage();
      context.refresh();
      context.stop();
      context.start();
      context.close();
      context.start();
   }
}