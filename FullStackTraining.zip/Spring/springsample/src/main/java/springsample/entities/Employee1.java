package springsample.entities;

public class Employee1 {
private String empname;
private String emailid;
private String dob;
private long contact;
private int salary;
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public long getContact() {
	return contact;
}
public void setContact(int contact) {
	this.contact = contact;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public Employee1(String empname, String emailid, String dob, long contact, int salary) {
	super();
	this.empname = empname;
	this.emailid = emailid;
	this.dob = dob;
	this.contact = contact;
	this.salary = salary;
}
public Employee1() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee1 [empname=" + empname + ", emailid=" + emailid + ", dob=" + dob + ", contact=" + contact
			+ ", salary=" + salary + "]";
}

}