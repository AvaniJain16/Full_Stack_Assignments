package springsample.dao;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;



import springsample.entities.Employee1;



public class RowMapperImpli implements RowMapper<Employee1> {



public Employee1 mapRow(ResultSet rs, int rowNum) throws SQLException {
// TODO Auto-generated method stub
Employee1 emp=new Employee1();
emp.setEmpname(rs.getString(1));  
emp.setEmailid(rs.getString(2));  
emp.setDob(rs.getString(3));  
emp.setContact(rs.getInt(4));
emp.setSalary(rs.getInt(5));

return emp;
}






}