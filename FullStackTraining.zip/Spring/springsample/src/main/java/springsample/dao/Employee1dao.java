package springsample.dao;

import java.util.List;

import springsample.entities.Employee1;



public interface Employee1dao {

public int insert(Employee1 emp);
public int updatedetails(Employee1 emp);
public int deletedetails(int empid);
public Employee1 selectDetails(int eid);



}