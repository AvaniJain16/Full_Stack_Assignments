package springsample.dao;

import springsample.entities.*;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.RowMapper;

public class Employee1daoimpli implements Employee1dao {

	private JdbcTemplate jdbctemp;

	public int insert(Employee1 emp) {
		String q = "insert into employee1(empname,emailid,dob,contact,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmailid(), emp.getDob(), emp.getContact(),
				emp.getSalary());
		return msg;
	}

	public int updatedetails(Employee1 emp) {
		String q = "update employee1 set empname=? where salary=?";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getSalary());
		return msg;
	}

	public int deletedetails(int empid) {
		String q = "delete from employee1 where salary=?";
		int msg = this.jdbctemp.update(q, empid);
		return msg;
	}

	public Employee1 selectDetails(int eid) {
		// TODO Auto-generated method stub
		String q = "select * from employee1 where salary=?";
		RowMapper<Employee1> rowmapper = new RowMapperImpli();
		Employee1 emp = this.jdbctemp.queryForObject(q, rowmapper, eid);
		return emp;

	}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public List<Employee1> RowMapper() {
		// TODO Auto-generated method stub
		return null;
	}
}