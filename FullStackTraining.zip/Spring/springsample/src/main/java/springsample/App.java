package springsample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springsample.dao.Employee1dao;
import springsample.entities.Employee1;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		
	
		try(Scanner sc = new Scanner(System.in)) {
            System.out.print(" Enter user name => ");
            String userName = sc.nextLine();

            System.out.print(" Enter password => ");
            String password = sc.nextLine();

            if ("yash".equals(userName) && "root".equals(password)) {
                System.out.println(" User successfully logged-in.. ");
            } else {
                System.out.println(" In valid userName of password ");
            }
        }
		
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("Applicationcontext.xml");
		Employee1dao empdao = context.getBean("Employee1dao", Employee1dao.class);
		
		
		Employee1 e = new Employee1();
		e.setEmpname("yash");
		e.setEmailid("jay.com");
		e.setDob("2010-11-10");
		e.setContact(98748);
		e.setSalary(50000);
		
		
		try {
		Scanner sc = new Scanner(System.in);
		char wish;
		int r;
		x:
		do{

	        System.out.println("\nEnter your choice :\n1.Insert detail \n2.Update detail \n3.Delete detail \n4. Select detail \n5.Exit \n");
	        r = sc.nextInt();
	        switch(r){
	            case 1: int r1 = empdao.insert(e);
	            System.out.println(r1 + "Employee added Successfully ");
	                break;
	            case 2: int r2 = empdao.updatedetails(e);
	            System.out.println(r2 + "Employee details updated ");
	                break;
	            case 3: int r3=empdao.deletedetails(50000);                     
	                break;
	            case 4: Employee1 r4=empdao.selectDetails(50000);
	    		System.out.println(r4);                
	               
	            case 5:break x;
	            
	            default:
	                System.out.println("Enter valid option");
	                break;
	               
	        }
	           
	            System.out.println("\nContinue : (y/n)");
	            wish=sc.next().charAt(0); 
	            if(!(wish=='y'||wish=='Y'||wish=='n'||wish=='N'))
	            {
	                System.out.println("Invalid Option1");
	                System.out.println("\nContinue : (y/n)");
	                wish=sc.next().charAt(0); 
	            }
		}  
		
	    while(wish=='y'||wish=='Y');		
	        }        
	            catch(Exception e1)
	            {
	                System.out.println("Not a valid input");
	            }
		
	}	
}