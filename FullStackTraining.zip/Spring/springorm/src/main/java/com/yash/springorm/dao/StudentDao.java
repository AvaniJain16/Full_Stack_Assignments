package com.yash.springorm.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.yash.springorm.entities.Student;



public class StudentDao {
	private HibernateTemplate hibernateTemp;

	@Transactional
	public int insert(Student stu) {
		Integer i = (Integer) this.hibernateTemp.save(stu);
		return i;
	}

	public Student getStudentDetails(int stuid) {
		Student stu = this.hibernateTemp.get(Student.class, stuid);
		return stu;
	}

	public List<Student> getAllStudents() {
		List<Student> stu = this.hibernateTemp.loadAll(Student.class);
		return stu;
	}

	@Transactional
	public void deleteDetails(int stuid) {
		Student stu = this.hibernateTemp.get(Student.class, stuid);
		this.hibernateTemp.delete(stu);
	}

	@Transactional
	public void updateDetails(Student stu) {
		this.hibernateTemp.update(stu);
	}

	public HibernateTemplate getHibernateTemp() {
		return hibernateTemp;
	}

	public void setHibernateTemp(HibernateTemplate hibernateTemp) {
		this.hibernateTemp = hibernateTemp;
	}
}
