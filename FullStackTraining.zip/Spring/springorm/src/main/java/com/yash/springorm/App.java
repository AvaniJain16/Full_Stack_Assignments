package com.yash.springorm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springorm.dao.StudentDao;
import com.yash.springorm.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("Config.xml");
		StudentDao studao = context.getBean("StudentDao", StudentDao.class);
		//Student stu = new Student();
		//int msg= studao.insert(stu);
		//System.out.println(msg + " values inserted!");
		Student s =studao.getStudentDetails(1);
		System.out.println(s);
    }
}
