package springmvc2.controller;


import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {

	List < String > newlist = Arrays.asList("Sunday", "Monday", "Tuesday");
	
@RequestMapping("/home")
public String home1(List model)
{
	//model.addAll(newlist);
return "index";
}

@RequestMapping("/about")
public String home2()
{
return "home";
}
}