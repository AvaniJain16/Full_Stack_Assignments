package springrowmap;

import java.util.List;
import springrowmap.dao.EmployeeDao;
import springrowmap.entities.Employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Applicationcontext.xml");
		EmployeeDao dao = (EmployeeDao) context.getBean("edao");
		List<Employee> list = dao.getAllEmployeesRowMapper();

		for (Employee e : list)
			System.out.println(e);
	}
}