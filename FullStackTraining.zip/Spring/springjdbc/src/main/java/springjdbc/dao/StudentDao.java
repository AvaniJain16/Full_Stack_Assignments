package springjdbc.dao;

import springjdbc.entities.Student;



public interface StudentDao {

public int insert(Student stu);
public int updatedetails(Student stu);
public int deletedetails(int stuid);



}