package springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import springjdbc.dao.StudentDao;
import springjdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("Applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);

		Student s = new Student();
		s.setId(108);
		s.setName("jaynam");
		//int r = stdao.insert(s);
		//int r=stdao.updatedetails(s);
		int r=stdao.deletedetails(107);
		//System.out.println(r + "Student added Successfully ");
		//System.out.println(r + "Student details updated ");
		System.out.println(r + "Student deleted Successfully ");
	}
}