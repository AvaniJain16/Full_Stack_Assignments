package com.yash.springjpa;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface Repository extends CrudRepository<Customer, Long> {

  List<Customer> findByLastName(String lastName);

  Customer findById(long id);
}
