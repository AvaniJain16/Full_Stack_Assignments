package springmessage;

public class Application {

}
