package springmodelattri.controller;

import org.springframework.web.bind.annotation.RestControllerAdvice;

import springmodelattri.model.User;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class DemoController {

	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("user", new User());
		return "index";
	}

	@PostMapping("save")
	public String save(@ModelAttribute("user") User user, Model model) {
		model.addAttribute("user", user);
		return "response";
	}
}

/*
 * @RestControllerAdvice public class DemoController {
 * 
 * @PostMapping("/date") public String date(@RequestParam("date")
 * 
 * @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date date) { return
 * "response"; }
 * 
 * @PostMapping("/local-date") public void localDate(@RequestParam("localDate")
 * 
 * @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate localDate) { // ...
 * }
 * 
 * @PostMapping("/local-date-time") public void
 * dateTime(@RequestParam("localDateTime")
 * 
 * @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime
 * localDateTime) { // ... } }
 */
