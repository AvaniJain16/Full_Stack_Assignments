package springfactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Draw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext context= new ClassPathXmlApplicationContext("Applicationcontext.xml");
shape shp =(shape)context.getBean("circle");

System.out.println(context.getMessage("greeting", null, "Default Greeting", null));
	}

}
