package springfactory;

public class shape {
	
	String circle;

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	@Override
	public String toString() {
		return "shape [circle=" + circle + "]";
	}

}
