package com.yash.springaopdemo;

import org.aspectj.lang.annotation.Aspect;

/**
 * Hello world!
 *
 */
@Aspect
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
