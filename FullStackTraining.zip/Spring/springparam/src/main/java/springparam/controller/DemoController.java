package springparam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

	@Controller
	public class DemoController {
		
		@RequestMapping("/index")
		public String home()
		{
		return "index";
		}

		@RequestMapping(path="/request",method=RequestMethod.POST)
		public String handlerequest(@RequestParam("password") String password)
		{
		System.out.println(password);

		return "";
		}
	
}
