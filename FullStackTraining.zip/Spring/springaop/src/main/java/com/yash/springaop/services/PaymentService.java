package com.yash.springaop.services;

public interface PaymentService {

public void makePayment();



}