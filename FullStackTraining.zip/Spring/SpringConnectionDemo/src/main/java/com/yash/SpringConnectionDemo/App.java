package com.yash.SpringConnectionDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("Applicationcontextxml.xml");
        JdbcTemplate temp = context.getBean("jdbctemp",JdbcTemplate.class);
        String q="insert into student(id,name) values(?,?)";

        int msg= temp.update(q,105,"jaynam sanghvi");
        System.out.println("record inserted" +msg);
    }
}
