create database Example;
create table example
( name varchar(20),
id int(5));
