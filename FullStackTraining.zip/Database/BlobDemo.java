import java.sql.*;
import java.io.*;
class BlobDemo{
public static void main(String[] args){
try{
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/yash";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	
	  Statement stmt = con.createStatement();
      stmt.execute("CREATE TABLE ImTable( Name VARCHAR(255), Image BLOB)");
      System.out.println("Table Created");

      String query = "INSERT INTO ImTable(Name,image) VALUES (?, ?)";
      PreparedStatement pstmt = con.prepareStatement(query);
      pstmt.setString(1, "sample image");
      FileInputStream fin = new FileInputStream("C:\\Users\\Avani.Jain\\Pictures\\Saved Pictures\\images.jpg");
      pstmt.setBlob(2, fin);
      pstmt.execute();
 
      ResultSet rs = stmt.executeQuery("select * from ImTable");
      int i = 1;
      System.out.println("Contents of the table are: ");
      while(rs.next()) {
         System.out.println(rs.getString("Name"));
         Blob blob = rs.getBlob("Image");
         byte byteArray[] = blob.getBytes(1,(int)blob.length());
         FileOutputStream outPutStream = new
         FileOutputStream("C:\\Users\\Avani.Jain\\Pictures\\Saved Pictures\\blob_output"+i+".jpg");
         outPutStream.write(byteArray);
         System.out.println("C:\\Users\\Avani.Jain\\Pictures\\Saved Pictures\\blob_output"+i+".jpg");
         System.out.println();
         i++;	
	}
	con.close();
}
catch(Exception e){
System.out.println(e);
}
}
}