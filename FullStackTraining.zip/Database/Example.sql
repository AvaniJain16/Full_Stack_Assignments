create table example(
name varchar(20),
id int(5),
showtime time,
showstamp timestamp(2)

);


create temporary table a select * from example;
