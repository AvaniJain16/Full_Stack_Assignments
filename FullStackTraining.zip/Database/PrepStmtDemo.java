import java.sql.*;
class PrepStmtDemo{
public static void main(String[] args){
	try{
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/Yash";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	PreparedStatement stmt=con.prepareStatement("insert into Fruit values(?,?)");  
    stmt.setInt(1,1); 
    stmt.setString(2,"Yash");	
  
    int i=stmt.executeUpdate();  
    System.out.println(i+" records inserted");  
	con.close();
	}
	catch(Exception e){
		System.out.println(e);
	}

}
}