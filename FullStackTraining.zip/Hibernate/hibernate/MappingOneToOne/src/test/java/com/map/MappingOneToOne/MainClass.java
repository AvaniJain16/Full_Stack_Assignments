package com.map.MappingOneToOne;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class MainClass {

	
	public static void main(String[] args) {
		
		try
		{
			 StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
			    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
			    
			    SessionFactory sfactory =meta.getSessionFactoryBuilder().build();
			    Session s = sfactory.openSession();
			    Transaction t = s.beginTransaction();
			    
			    Tab1 t1 = new Tab1();
			    t1.setId(1);
			    t1.setName("sandeep");
			    
			    Tab2 t2 = new Tab2();
			    t2.setId(1);
			    t2.setCity("Indore");
			    t1.setA_id(t2.getId());
			    s.save(t1);
			    s.save(t2);
			    
			    t.commit();
			    s.close();
			    
			    
			    
			    
			    
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
