package com.pract.TableParConcreateClass;

import javax.persistence.*;

@Entity
@Table(name="Reg_Emp")
@AttributeOverrides({
	@AttributeOverride(name="id" ,column =@Column(name="id")),
	@AttributeOverride(name="id" ,column = @Column(name="name"))
	
})
public class Reg_Emp  extends Emp1{
	
	public Reg_Emp(int salary, int bonus) {
		super();
		this.salary = salary;
		this.bonus = bonus;
	}
	public Reg_Emp(){
	
	}

	@Column(name="salary")
	public int salary;
	
	@Column(name="bonus")
	private int bonus;
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}


	
	
	
	
	
}
