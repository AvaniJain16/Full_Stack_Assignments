package com.pract.TableParHirarchy;

import javax.persistence.*;

@Entity
@DiscriminatorValue("regular_Emp")
public class Regular_Emp extends Employee{



	@Column(name="salary")
	private int salary;
	

	@Column(name="bonus")
	private int bonus;
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	
	public Regular_Emp(int salary, int bonus) {
		super();
		this.salary = salary;
		this.bonus = bonus;
	}
	public Regular_Emp() {
	
	}
}
