package com.pract.TableParHirarchy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class MainClass {
public static void main(String[] args) {
	try
	{
	StandardServiceRegistry str = new StandardServiceRegistryBuilder().configure("hiber.cfg.xml").build();
	Metadata meta = new MetadataSources(str).getMetadataBuilder().build();
	
	SessionFactory  sfactory = meta.getSessionFactoryBuilder().build();
	Session s = sfactory.openSession();
	Transaction t = s.beginTransaction();
	
	Employee e= new Employee();
	e.setName("abc");
	
	Regular_Emp e1 = new Regular_Emp();
	e1.setName("abc1");
	e1.setSalary(99999000);
	e1.setBonus(100000);
	
	Temp_emp e2 = new Temp_emp();
	e2.setName("abc2");
	e2.setPay_pr_hour(50000);
	e2.setDuration(9);
	
	s.persist(e);
	s.persist(e1);
	s.persist(e2);
	
	t.commit();
	s.close();
	
	
	

	}
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	}

	
	
}
