package com.map.MappingOneToOneByHbm;

public class Tab1 {


	private int id;
	private String name;
	private Tab2 a_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Tab2 getA_id() {
		return a_id;
	}
	public void setA_id(Tab2 a_id) {
		this.a_id = a_id;
	}
	public Tab1(int id, String name, Tab2 a_id) {
		super();
		this.id = id;
		this.name = name;
		this.a_id = a_id;
	}
	public Tab1() {
		
	}
	
	
}
