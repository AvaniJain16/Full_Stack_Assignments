package com.hibernet2.user;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import java.util.Scanner;



public class UserDataSave {
	
	
	public static void main(String[] args)
	{
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		try
		{
			StandardServiceRegistry str = new StandardServiceRegistryBuilder().configure("hibernet.cfg.xml").build();
			Metadata meta =new MetadataSources(str).getMetadataBuilder().build();
			
			SessionFactory factory = meta.getSessionFactoryBuilder().build();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			
			User user = new User();
			int i;
			for(i=1;i<=5; i++)
			{
				System.out.println("Enter The userName");
				String username = sc1.nextLine();
				System.out.println("Enter The email");
				String email = sc1.nextLine();
				System.out.println("Enter The Age");
				int age = sc2.nextInt();
				
				user.setUsername(username);
				user.setEmail(email);
				user.setAge(age);
				
			
				
			}
			session.save(user);
			t.commit();
			System.out.println("User save Sucessfully");
			factory.close();
			session.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
