package com.hibernate.HibernateDemo2SelectDataFromDatabase;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.mysql.cj.Query;

public class EmpDao {

	public static SessionFactory s1;
	public static SessionFactory data()
	{
		try {
		StandardServiceRegistry reg = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(reg).getMetadataBuilder().build();
		s1 = meta.getSessionFactoryBuilder().build(); 
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return s1;
	}
	
	public static void main(String[] args) {
		
		data();
		Session s3 = s1.openSession();
		Transaction t1= s3.beginTransaction();
		
		Emp obj = new Emp();
		
		Emp emp = (Emp)s3.get(Emp.class, 1);
		 
		System.out.println(emp.getId());
	
		System.out.println(emp.getSalary());
		
		
		
		
		
	}
}
