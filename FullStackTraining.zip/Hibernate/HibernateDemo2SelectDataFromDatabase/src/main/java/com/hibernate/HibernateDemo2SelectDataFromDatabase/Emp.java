package com.hibernate.HibernateDemo2SelectDataFromDatabase;

public class Emp {

	private int id;

	private String salary;
	
	public void setId(int id){this.id =id;}

	public void setSalary(String salary){this.salary = salary;}
	public int getId(){return id;}

	public String getSalary(){return salary;}
	public Emp()
	{
		
	}
	
}
