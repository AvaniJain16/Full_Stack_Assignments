import java.awt.*; 
import java.awt.event.*;  
import javax.swing.*; 
import java.sql.*;

class OnlineTest extends JFrame implements ActionListener  
{  
    JLabel l; 
    JRadioButton jb[]=new JRadioButton[5];  
    JButton b1,b2,b3;  
    ButtonGroup bg;  
    int count=0,attempted=0,current=-1,x=1,y=1,now=0; 
    long StartTime,EndTime,seconds,minutes,flag=0;; 
    int a;
    OnlineTest(String s)  
    {  
        super(s);  
        l=new JLabel();  
        add(l);  
        bg=new ButtonGroup();  
        for(int i=0;i<5;i++)  
        {  
            jb[i]=new JRadioButton();     
            add(jb[i]);  
            bg.add(jb[i]);  
        }
		welcome(); 
        b1=new JButton("Start");   
        b1.addActionListener(this); 
        add(b1); 
        b2=new JButton("Previous"); 
		b2.addActionListener(this); 
		add(b2);
        b3=new JButton("Result"); 
        b3.addActionListener(this);  
        add(b3);
        l.setBounds(30,40,450,20);  
        if(current !=-1)
        {   
            jb[0].setBounds(50,80,100,20);  
            jb[1].setBounds(50,110,100,20);  
            jb[2].setBounds(50,140,100,20);  
            jb[3].setBounds(50,170,100,20);  
        }
        b1.setBounds(100,240,100,30);  
        b2.setBounds(270,240,100,30);  
        b3.setBounds(400,240,100,30);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        setLayout(null);  
        setLocation(250,100);  
        setVisible(true);  
        setSize(600,350);  
    }  
    public void actionPerformed(ActionEvent e)  
    {  
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            if(e.getSource()==b1 && current ==9 ) 
            {
                adduserans(); 
                JOptionPane.showMessageDialog(this,"No more questions. Please go back to previous question or end test and see result.\n");   
            }
            else if(e.getSource()==b1)  
            {  
                if(current == -1) 
                {
                    StartTime = System.currentTimeMillis(); 
                    b1.setText("Next"); 
                }
                else
                    adduserans(); 
                    current++; 
                    settext(); 
            }  
            else if(e.getSource()==b2 && current ==0 ) 
            {
                adduserans(); 
                JOptionPane.showMessageDialog(this,"No more questions. Please go back to next question or end test and see result.\n");   
            }
            else if(e.getSource()==b2)  
            {   
                current--;  
                adduserans();
                settext();   
            }  
            else if(e.getActionCommand().equals("Result"))  
            {  
                EndTime = System.currentTimeMillis(); 
                EndTime-=StartTime; 
                EndTime/=1000; 
                if(EndTime>=60) 
                {
                    seconds = EndTime%60; 
                    EndTime/=60; 
                    flag=1;
                    if(EndTime>=60) 
                    {
                        flag=2;
                        minutes=EndTime%60; 
                        EndTime/=60; 
                    }
                }
                current++;   
                check();  
                if(flag==0)
                 a = JOptionPane.showConfirmDialog(this,"Attempted questions: "+attempted+" / 10\nTime taken: "+EndTime+" seconds\nYour Score: "+count+" / 10\nPercentage: "+(count*10)+" %\nDo you wish to see the answer key ?");  
                else if(flag==1)
                 a = JOptionPane.showConfirmDialog(this,"Attempted questions: "+attempted+" / 10\nTime taken: "+EndTime+" minutes "+seconds+" seconds\nYour Score: "+count+" / 10\nPercentage: "+(count*10)+" %\nDo you wish to see the answer key ?");     
                else
                 a = JOptionPane.showConfirmDialog(this,"Attempted questions: "+attempted+" / 10\nTime taken: "+EndTime+" hours "+minutes+" minutes "+seconds+" seconds\nYour Score: "+count+" / 10\nPercentage: "+(count*10)+" %\nDo you wish to see the answer key ?");     
               
                if(a==JOptionPane.YES_OPTION) 
                    showAnswerKey();
                else
                {
                    stmt.executeUpdate("delete from ans");
                    stmt.executeUpdate("delete from testans");
                    stmt.executeUpdate("delete from testques");
                    stmt.executeUpdate("delete from ques");
                    System.exit(0);  
                }
            } 
        }
        catch(Exception ex)
        {
            System.out.println("actionPerformed"+ex);
        } 
    }  
    void welcome()  
    {
        l.setText("Welcome to the online test. Click start.") ;
    }
    void settext() 
    {  
        jb[4].setSelected(true);  
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            if(current==0)  
            {    
                String sql="select * from testques where num=1"; 
                ResultSet rs = stmt.executeQuery(sql); 
                rs.next();  
                String s1 =rs.getString("question"); 
                String s2 =rs.getString("option1"); 
                String s3 =rs.getString("option2"); 
                String s4 =rs.getString("option3"); 
                String s5 =rs.getString("option4"); 
                l.setText("Q.1 " +s1); 
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==1)  
            {  
                String sql="select * from testques where num=2";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.2 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==2)  
            {  
                String sql="select * from testques where num=3";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.3 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==3)  
            {  
                String sql="select * from testques where num=4";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.4 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==4)  
            {  
                String sql="select * from testques where num=5";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.5 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==5)  
            {  
                String sql="select * from testques where num=6";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.6 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==6)  
            {  
                String sql="select * from testques where num=7";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.7 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==7)  
            {  
                String sql="select * from testques where num=8";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.8 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==8)  
            {  
                String sql="select * from testques where num=9";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.9 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            if(current==9)  
            {  
                String sql="select * from testques where num=10";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("question");
                String s2 =rs.getString("option1");
                String s3 =rs.getString("option2");
                String s4 =rs.getString("option3");
                String s5 =rs.getString("option4");
                l.setText("Q.10 "+s1);  
                jb[0].setText(s2);jb[1].setText(s3);jb[2].setText(s4);jb[3].setText(s5);  
            }  
            l.setBounds(30,40,450,20);  
            for(int i=0,j=0;i<=90;i+=30,j++)  
                jb[j].setBounds(50,80+i,200,20);  
        }   
        catch(Exception e)
        {
            System.out.println("settext\n"+e);
        }
    }  
    void adduserans() 
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            for(int i=0;i<=3;i++)
            {
                if(jb[i].isSelected()) 
                {
                    String sql1 = "insert into testans(num,userans) values("+(current+1)+",'"+jb[i].getText()+"') on duplicate key update userans='"+jb[i].getText()+"'";
                    stmt.executeUpdate(sql1);
                    break;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("adduserans\n"+e);
        }
    }
    void check() 
    {  
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
          String url="jdbc:mysql://localhost:3306/test01";
		  String user="root";
		  String pass="root";
		  Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            for(int i=1;i<11;i++)
            {
                String sql="select userans, correctans from testans where num="+i+"";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("userans");
                String s2 =rs.getString("correctans");
                if(!(s1.equals("")))  
                    attempted++;
                if(s1.equals(s2)) 
                 count++;
            }
        }
        catch(Exception e)
        {
            System.out.println("check\n"+e);
        }
    }
    void showAnswerKey() 
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            String answerkey="";
            answerkey+="Answer Key:\nQ.No.  Your answer    Correct Answer\n";
            for(int i=1;i<=10;i++)
            {
                String sql="select userans, correctans from testans where num="+i+"";
                ResultSet rs = stmt.executeQuery(sql);
                rs.next();
                String s1 =rs.getString("userans"); 
                if(s1.equals("")) 
                    s1="NA";
                String s2 =rs.getString("correctans"); 
                if(i<=9)
                 answerkey+="   "+(char)(i+48)+"         "+s1+"         "+s2+"\n";
                else 
                 answerkey+="  10"+"         "+s1+"         "+s2+"\n";
            }
            JOptionPane.showMessageDialog(this,answerkey); 
            stmt.executeUpdate("delete from ans");
            stmt.executeUpdate("delete from testans");
            stmt.executeUpdate("delete from testques");
            stmt.executeUpdate("delete from ques");
            System.exit(0);
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("showAnswerKey\n"+e);
        }
    }
    static void quesDBcon() 
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into ques values(1,'What is the implicit return type of constructor?','A class object','No return type','Void','None')");
            stmt.executeUpdate("insert into ques values(2,'When is the object created with a new keyword?','At run time','At compile time','Depend on code','None')");
            stmt.executeUpdate("insert into ques values(3,'Identify the incorrect constructor type.','Copy constructor','parameterized constructor','Friend constructor','Default constructor')");
            stmt.executeUpdate("insert into ques values(4,'Identify the scope resolution operator.',':','::','?:','None')");
            stmt.executeUpdate("insert into ques values(5,'Choose the option below which is not a member of the class.','Friend function','Static function','Virtual function','Const function')");
            stmt.executeUpdate("insert into ques values(6,'What is the number of parameters that a default constructor requires?','0','1','2','3')");
            stmt.executeUpdate("insert into ques values(7,'Data members and member functions of a class are private. default. True or False?','True','False','Depends on code','None')");
            stmt.executeUpdate("insert into ques values(8,'Under which pillar of OOPS do base class and derived class relationships come?','Encapsulation','Abstraction','Inheritance','polymorphism')");
            stmt.executeUpdate("insert into ques values(9,'Which of the following functions can be inherited from the base class?','Constructor','Destructor','Static','None')");
            stmt.executeUpdate("insert into ques values(10,'Which of the following is not a type of inheritance?','Multiple','Multilevel','Distributed','Heirarchical')");
            stmt.executeUpdate("insert into ques values(11,'Why is reusability a desirable feature?','Reduce compilation time','Decrease testing time','Lowers maintenance cost','None')");
            stmt.executeUpdate("insert into ques values(12,'Identify the operators which cannot be overloaded','?:','.(dot)','>>','Both A and B')");
            stmt.executeUpdate("insert into ques values(13,'Another name of overloading is?','Psuedo polymorphism','Trasient polymorphism','Virtual polymorphism','Ad-hoc polymorphism')");
            stmt.executeUpdate("insert into ques values(14,'Choose the option below which can show polymorphism.','||','<<','&&','+=')");
            stmt.executeUpdate("insert into ques values(15,'To access data members of a class, which of the following is used?','Dot operator','Arrow operator','Both as per required','Dot, arrow, direct call')");
            stmt.executeUpdate("insert into ques values(16,'Identify the feature, which is used to reduce the use of nested classes.','Binding','Encapsulation','Inheritance','Abstraction')");
            stmt.executeUpdate("insert into ques values(17,'Choose the option below which is used to free the memory allocated for an object in C++.','Free()','Unallocate()','Delete','Collect')");
            stmt.executeUpdate("insert into ques values(18,' Identify the option below which is not a property of the object.','Names','Attribute','Properties','Identity')");
            stmt.executeUpdate("insert into ques values(19,'In which of the following is memory allocated for the objects?','RAM','ROM','Cache','HDD')");
            stmt.executeUpdate("insert into ques values(20,'How do encapsulation and abstraction differ?','Hiding and binding','Binding and hiding','Both hiding','None')");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("quesDBcon\n"+e);
        }
    }
    static void ansDBcon() 
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into ans values(1,'','No return type')");
            stmt.executeUpdate("insert into ans values(2,'','At run time')");
            stmt.executeUpdate("insert into ans values(3,'','Copy cnstructor')");
            stmt.executeUpdate("insert into ans values(4,'','::')");
            stmt.executeUpdate("insert into ans values(5,'','Friend function')");
            stmt.executeUpdate("insert into ans values(6,'','0')");
            stmt.executeUpdate("insert into ans values(7,'','True')");
            stmt.executeUpdate("insert into ans values(8,'','Inheritance')");
            stmt.executeUpdate("insert into ans values(9,'','None')");
            stmt.executeUpdate("insert into ans values(10,'','Distributed')");
            stmt.executeUpdate("insert into ans values(11,'','Decrease testing time')");
            stmt.executeUpdate("insert into ans values(12,'','Both A and B')");
            stmt.executeUpdate("insert into ans values(13,'','Ad-hoc polymorphism')");
            stmt.executeUpdate("insert into ans values(14,'','<<')");
            stmt.executeUpdate("insert into ans values(15,'','Both as per required')");
            stmt.executeUpdate("insert into ans values(16,'','Inheritance')");
            stmt.executeUpdate("insert into ans values(17,'','Delete')");
            stmt.executeUpdate("insert into ans values(18,'','Names')");
            stmt.executeUpdate("insert into ans values(19,'','RAM')");
            stmt.executeUpdate("insert into ans values(20,'','Binding and hiding')");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("ansDBcon\n"+e);
        }
    }
    static void pickrandom()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/test01";
			String user="root";
			String pass="root";
			Connection con =DriverManager.getConnection(url,user,pass);
            Statement stmt = con.createStatement();
            int a[]=new int[21];
            int c=0;
            int p;
            for(int i=0;i<=20;i++)
                a[i]=0;
            while(c!=10)
            {
                p=1+(int)(Math.random()*20); 
                if(a[p]==0)
                {
                    a[p]=1; 
                    c++; 
                }
            }
            c=0;
            for(int i=1;i<=20;i++)
            {
                if(a[i]==1) 
                {
                    c++;
                    String sql="select * from ques where num="+i+"";
                    ResultSet randomrs = stmt.executeQuery(sql);
                    randomrs.next();
                    String s1 =randomrs.getString("question");
                    String s2 =randomrs.getString("option1");
                    String s3 =randomrs.getString("option2");
                    String s4 =randomrs.getString("option3");
                    String s5 =randomrs.getString("option4");
                    stmt.executeUpdate("insert into testques values("+c+",'"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"')");
                    randomrs.close();
                    sql="select * from ans where num="+i+"";
                    randomrs = stmt.executeQuery(sql);
                    randomrs.next();
                    s1 =randomrs.getString("correctans");
                    stmt.executeUpdate("insert into testans values("+c+",'','"+s1+"')");
                    randomrs.close();

                }
            }
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("pickrandom\n"+e);
        }
    }
    public static void main(String s[])
    {  
        quesDBcon(); //creating question-option database
        ansDBcon(); //creating user answer-correct answer database
        pickrandom(); //creating question-option database that will be asked to student
        new OnlineTest("Online Test Taker System");  // creating object 
    }  
}  