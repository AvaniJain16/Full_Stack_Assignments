import java.util.Scanner;

class SingleRoom 
{
    private String name1;
    private String contact1;
    private String id1;   
	
    SingleRoom()
    {
        this.name1="";
    }
	
    Scanner userinput = new Scanner(System.in);

    public void setName(String name1){
        this.name1=name1;
        name1= userinput.next();     
    }

    public String getName(){

        return name1;
    }
	 public void setContact(String contact1){
        this.contact1=contact1;
        contact1= userinput.next();     
    }

    public String getContact(){

        return contact1;
    }
	 public void setId(String id1){
        this.id1=id1;
        id1= userinput.next();     
    }

    public String getName(){

        return id1;
    }
}
class DoubleRoom extends SingleRoom 
{ 
    String name2;
    String contact2;
    String id2;  
    
    DoubleRoom()
    {
        this.name1="";
        this.name2="";
    }
    DoubleRoom(String name1,String contact1,String id1,String name2,String contact2,String id2)
    {
        this.name1=name1;
        this.contact1=contact1;
        this.id1=id1;
        this.name2=name2;
        this.contact2=contact2;
        this.id2=id2;
    }
}
class NotAvailable extends Exception
{
  
    public String toString()
    {
        return "Not Available!";
    }
}

class Holder
{
    DoubleRoom doubleroom[]=new DoubleRoom[20]; 
    SingleRoom singleroom[]=new SingleRoom[20]; 
} 

class Hotel
{
    static Holder hotelOb=new Holder();
    static Scanner sc = new Scanner(System.in);
	SingleRoom s= new SingleRoom();
    static void CustDetails(int i,int rn)
    {
        String name1, contact1, id1;
        String name2 = null, contact2 = null; 
        String id2="";
		setName();
        System.out.print("\nEnter customer name: " +this.getName());
		setContact();
        System.out.print("Enter contact number: " +this.getContact());
         setId();
        System.out.print("Enter id number: " +this.getId());
        if(i==1)
        {
        System.out.print("Enter second customer name: ");
        name2 = sc.next();
        System.out.print("Enter contact number: ");
        contact2=sc.next();
        System.out.print("Enter id number: ");
        id2 = sc.next();
        }      
        
          switch (i) {
            case 1:hotelOb.doubleroom[rn]=new DoubleRoom(name1,contact1,id1,name2,contact2,id2);
                break;        
            case 2:hotelOb.singleroom[rn]=new SingleRoom(name1,contact1,id1);
                break;
            default:System.out.println("Wrong option");
                break;
        }
    }
    
    static void bookRoom(int i)
    {
        int j;
        int rn;
        System.out.println("\nChoose room number from : ");
        switch (i) {
            case 1:
                for(j=0;j<hotelOb.doubleroom.length;j++)
                {
                    if(hotelOb.	doubleroom[j]==null)
                    {
                        System.out.print(j+1+",");
                    }
                }
                System.out.print("\nEnter room number: ");
                try{
                rn=sc.nextInt();
                rn--;
                if(hotelOb.doubleroom[rn]!=null)
                    throw new NotAvailable();
                CustDetails(i,rn);
                }
                catch(Exception e)
                {
                    System.out.println("Invalid Option!");
                    return;
                }
                break;
            case 2:
                  for(j=0;j<hotelOb.singleroom.length;j++)
                {
                    if(hotelOb.singleroom[j]==null)
                    {
                        System.out.print(j+21+",");
                    }
                }
                System.out.print("\nEnter room number: ");
                try{
                rn=sc.nextInt();
                rn=rn-21;
                if(hotelOb.singleroom[rn]!=null)
                    throw new NotAvailable();
                CustDetails(i,rn);
                }
                catch(Exception e)
                {
                    System.out.println("Invalid Option!");
                    return;
                }
                break;
            default:
                System.out.println("Enter valid option");
                break;
        }
        System.out.println("Room Booked");
    }
    
    static void features(int i)
    {
        switch (i) {
            case 1:System.out.println("Number of double beds : 1\nAC : Yes\nCharge per day:3500 ");
                break;
            case 2:System.out.println("Number of double beds : 1\nAC : No\nCharge per day:3000  ");
                break;
            case 3:System.out.println("Number of single beds : 1\nAC : Yes\nCharge per day:2000  ");
                break;
            case 4:System.out.println("Number of single beds : 1\nAC : No\nCharge per day:1500 ");
                break;
            default:
                System.out.println("Enter valid option");
                break;
        }
    }
    
    static void availability(int i)
    {
      int j,count=0;
        switch (i) {
            case 1:
                for(j=0;j<hotelOb.doubleroom.length;j++)
                {
                    if(hotelOb.doubleroom[j]==null){
                        System.out.print(j+1+",");
                        count++;
					}
                }
                break;
            case 2:
                for(j=0;j<hotelOb.singleroom.length;j++)
                {
                    if(hotelOb.singleroom[j]==null){
						 System.out.print(j+21+",");
                        count++;
					}
                }
                break;
           default:
                System.out.println("\nEnter valid option!");
                break;
        }
		System.out.println("\n");
        System.out.println("Number of rooms available : "+count);
    }
    
    static void deallocate(int rn,int rtype)
    {
        int j;
        char w;
        switch (rtype) {
            case 1:               
                if(hotelOb.doubleroom[rn]!=null)
                    System.out.println("Room used by "+hotelOb.doubleroom[rn].name1);                
                else 
                {    
                    System.out.println("Already Empty");
                        return;
                }
                System.out.println("Do you want to checkout ?(y/n)");
                 w=sc.next().charAt(0);
                if(w=='y'||w=='Y')
                {
                    hotelOb.doubleroom[rn]=null;
                    System.out.println("Deallocated succesfully");
                }
                
                break;
            case 2:
                if(hotelOb.singleroom[rn]!=null)
                    System.out.println("Room used by "+hotelOb.singleroom[rn].name1);                
                else 
                 {    
                    System.out.println("Already Empty");
                        return;
                }
                System.out.println(" Do you want to checkout ? (y/n)");
                w=sc.next().charAt(0);
                if(w=='y'||w=='Y')
                {
                    hotelOb.singleroom[rn]=null;
                    System.out.println("Deallocated succesfully!");
                }
                
                break;
            default:
                System.out.println("\nEnter valid option : ");
                break;
        }
    }
}	

public class InputHotel {
    public static void main(String[] args){
        
        try
        {           
      
        Scanner sc = new Scanner(System.in);
        int ch,ch2;
        char wish;
        x:
        do{

        System.out.println("\nEnter your choice :\n1.Display room details\n2.Display room availability \n3.Book\n4.Checkout\n5.Exit\n");
        ch = sc.nextInt();
        switch(ch){
            case 1: System.out.println("\nChoose room type :\n1. Double Room \n2. Single Room\n");
                    ch2 = sc.nextInt();
                    Hotel.features(ch2);
                break;
            case 2: System.out.println("\nChoose room type :\n1. Double Room \n2. Single Room\n");
                     ch2 = sc.nextInt();
                     Hotel.availability(ch2);
                break;
            case 3: System.out.println("\nChoose room type :\n1. Double Room \n2. Single Room\n");
                     ch2 = sc.nextInt();
                     Hotel.bookRoom(ch2);                     
                break;
            case 4:                 
                System.out.print("Room Number -");
                     ch2 = sc.nextInt();
                     if(ch2>40)
                         System.out.println("Room doesn't exist");
                     else if(ch2>20)
                         Hotel.deallocate(ch2-21,2);
                     else if(ch2>0)
                         Hotel.deallocate(ch2-1,1);                   
                     else
                         System.out.println("Room doesn't exist");
                     break;
            case 5:break x;
                
        }
           
            System.out.println("\nContinue : (y/n)");
            wish=sc.next().charAt(0); 
            if(!(wish=='y'||wish=='Y'||wish=='n'||wish=='N'))
            {
                System.out.println("Invalid Option1");
                System.out.println("\nContinue : (y/n)");
                wish=sc.next().charAt(0); 
            }
            
        } 
    while(wish=='y'||wish=='Y');		
        }        
            catch(Exception e)
            {
                System.out.println("Not a valid input");
            }
	    }	
    }
